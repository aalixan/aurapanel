#!/usr/bin/env bash
set -Eeuo pipefail

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run as root: sudo bash install.sh" >&2
    exit 1
fi

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

if [[ -r /etc/os-release ]]; then
    . /etc/os-release
else
    echo "Cannot detect the operating system." >&2
    exit 1
fi

case "${ID:-}" in
    ubuntu|debian) ;;
    *) echo "Supported operating systems: Ubuntu and Debian." >&2; exit 1 ;;
esac

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip openssl

python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt

if [[ ! -f .env ]]; then
    touch .env
fi

chmod 600 .env
.venv/bin/python - <<'PY'
import arvm
arvm.init_db()
PY

cat > /etc/systemd/system/arvm.service <<SERVICE
[Unit]
Description=ARVM VPS Management Panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${SCRIPT_DIR}
ExecStart=${SCRIPT_DIR}/.venv/bin/python ${SCRIPT_DIR}/arvm.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=arvm

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable arvm.service
systemctl restart arvm.service

printf '\nARVM installation complete.\n'
printf 'Open: http://%s:5000/\n' "$(hostname -I | awk '{print $1}')"
printf 'Activate the panel by entering a signed license key supplied by the ARVM owner.\n'
printf 'Status: systemctl status arvm\n'
