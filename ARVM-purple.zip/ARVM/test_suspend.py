"""Test suspend and unsuspend VPS functionality."""
import os
import sys
import json
import tempfile
import unittest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Must set DATABASE_PATH before importing arvm
_test_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
_test_db.close()
os.environ['DATABASE_PATH'] = _test_db.name

# Prevent LXC/SocketIO from causing issues
with patch('arvm.SOCKETIO_AVAILABLE', False):
    import arvm
    arvm.SOCKETIO_AVAILABLE = False
    arvm.socketio = None


class TestSuspend(unittest.TestCase):
    def setUp(self):
        arvm.app.config['TESTING'] = True
        arvm.app.config['SERVER_NAME'] = 'test.local'
        arvm.app.config['WTF_CSRF_ENABLED'] = False
        self.client = arvm.app.test_client()
        self.ctx = arvm.app.app_context()
        self.ctx.push()

        # Initialize DB tables (this creates the main admin user)
        arvm.init_db()

        with arvm.get_db() as conn:
            pw = arvm.generate_password_hash('admin123')
            now = '2025-01-01T00:00:00'
            # Create test regular user
            conn.execute(
                "INSERT INTO users (username, email, password_hash, is_admin, created_at) "
                "VALUES (?, ?, ?, 0, ?)",
                ('user1', 'user1@test.local', pw, now)
            )
            # Create a test node (required by vps FK constraint)
            conn.execute(
                "INSERT INTO nodes (name, location, is_local, created_at, updated_at) "
                "VALUES (?, ?, 1, ?, ?)",
                ('test-node', 'local', now, now)
            )
            # Create test VPS (id=1, owned by user1, node=1)
            conn.execute(
                "INSERT INTO vps (container_name, user_id, node_id, status, suspended, suspended_reason, "
                "whitelisted, os_version, ram, cpu, storage, config, ip_address, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, 0, NULL, 0, ?, ?, ?, ?, ?, ?, ?, ?)",
                ('test-container', 2, 1, 'stopped', 'ubuntu-22.04',
                 '512', '1', '5120', '{}', '10.0.0.1', now, now)
            )

    def tearDown(self):
        self.ctx.pop()
        os.unlink(_test_db.name)

    def login(self, as_admin=True):
        """Helper: log in as admin or regular user."""
        # Default admin from init_db uses MAIN_ADMIN_PASSWORD (default 'admin')
        if as_admin:
            return self.client.post('/login', data={
                'username': arvm.MAIN_ADMIN_USERNAME, 'password': arvm.MAIN_ADMIN_PASSWORD
            }, follow_redirects=True)
        else:
            return self.client.post('/login', data={
                'username': 'user1', 'password': 'admin123'
            }, follow_redirects=True)

    def test_unlicensed_panel_requires_activation(self):
        """Protected pages remain unavailable without a configured activation."""
        arvm.set_setting('license_activated', '0')

        response = self.client.get('/login')
        api_response = self.client.get('/api/v1/health')

        self.assertEqual(response.status_code, 302)
        self.assertIn('/activate', response.location)
        self.assertEqual(api_response.status_code, 403)
        self.assertFalse(api_response.get_json()['success'])

    def test_license_activation_uses_signed_key(self):
        """Only an Ed25519-signed license for ARVM can activate the panel."""
        import base64
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

        def b64(data):
            return base64.urlsafe_b64encode(data).decode().rstrip('=')

        arvm.set_setting('license_activated', '0')
        response = self.client.post('/activate', data={'license_key': 'anything'})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(arvm.get_setting('license_activated'), '0')

        private = Ed25519PrivateKey.generate()
        public = private.public_key().public_bytes_raw()
        payload = json.dumps({
            'id': 'TEST-001',
            'product': 'ARVM',
            'expires_at': ''
        }, separators=(',', ':')).encode()
        token = b64(payload) + '.' + b64(private.sign(payload))

        with patch.object(arvm, 'LICENSE_PUBLIC_KEY_B64', b64(public)):
            response = self.client.post('/activate', data={'license_key': token})

        self.assertIn(response.status_code, (302, 200))
        self.assertEqual(arvm.get_setting('license_activated'), '1')
        self.assertEqual(arvm.get_setting('license_id'), 'TEST-001')

    def test_activated_panel_remains_available_without_local_key_file(self):
        """Activation no longer depends on a local license key file or env key."""
        arvm.set_setting('license_activated', '1')
        response = self.client.get('/login')
        self.assertNotEqual(response.status_code, 302)

    # ------------------------------------------------------------------ #
    #  SUSPEND TESTS
    # ------------------------------------------------------------------ #

    @patch('arvm.execute_lxc', new_callable=MagicMock)
    def test_suspend_success(self, mock_exec):
        """Admin can suspend a non-whitelisted VPS."""
        mock_exec.return_value = None
        self.login(as_admin=True)

        resp = self.client.post('/admin/vps/1/suspend',
                                data=json.dumps({'reason': 'Test suspend'}),
                                content_type='application/json')
        data = resp.get_json()
        self.assertEqual(resp.status_code, 200, data)
        self.assertTrue(data['success'])

        # Verify DB
        with arvm.get_db() as conn:
            row = conn.execute("SELECT suspended, suspended_reason FROM vps WHERE id=1").fetchone()
            self.assertEqual(row['suspended'], 1)
            self.assertEqual(row['suspended_reason'], 'Test suspend')

    @patch('arvm.execute_lxc', new_callable=MagicMock)
    def test_suspend_requires_admin(self, mock_exec):
        """Regular user cannot suspend."""
        mock_exec.return_value = None
        self.login(as_admin=False)

        resp = self.client.post('/admin/vps/1/suspend',
                                data=json.dumps({'reason': 'test'}),
                                content_type='application/json')
        self.assertEqual(resp.status_code, 403)
        data = resp.get_json()
        self.assertFalse(data['success'])

    def test_suspend_not_found(self):
        """Returns 404 for nonexistent VPS."""
        self.login(as_admin=True)

        resp = self.client.post('/admin/vps/999/suspend',
                                data=json.dumps({'reason': 'test'}),
                                content_type='application/json')
        self.assertEqual(resp.status_code, 404)
        data = resp.get_json()
        self.assertFalse(data['success'])
        self.assertIn('not found', data['error'].lower())

    def test_suspend_whitelisted(self):
        """Whitelisted VPS cannot be suspended."""
        with arvm.get_db() as conn:
            conn.execute("UPDATE vps SET whitelisted=1 WHERE id=1")
        self.login(as_admin=True)

        resp = self.client.post('/admin/vps/1/suspend',
                                data=json.dumps({'reason': 'test'}),
                                content_type='application/json')
        data = resp.get_json()
        self.assertEqual(resp.status_code, 403, data)
        self.assertFalse(data['success'])

    # ------------------------------------------------------------------ #
    #  UNSUSPEND TESTS
    # ------------------------------------------------------------------ #

    @patch('arvm.execute_lxc', new_callable=MagicMock)
    def test_unsuspend_success(self, mock_exec):
        """Admin can unsuspend a suspended VPS - DB is fully cleared."""
        mock_exec.return_value = None
        with arvm.get_db() as conn:
            conn.execute("UPDATE vps SET suspended=1, suspended_reason='Admin action' WHERE id=1")
        self.login(as_admin=True)

        resp = self.client.post('/admin/vps/1/unsuspend',
                                content_type='application/json')
        data = resp.get_json()
        self.assertEqual(resp.status_code, 200, data)
        self.assertTrue(data['success'])

        # Verify all suspended-related fields are cleared
        with arvm.get_db() as conn:
            row = conn.execute("SELECT suspended, suspended_reason, status, suspension_history FROM vps WHERE id=1").fetchone()
            self.assertEqual(row['suspended'], 0, 'suspended flag must be 0')
            self.assertIsNone(row['suspended_reason'], 'suspended_reason must be NULL')
            self.assertEqual(row['status'], 'stopped', 'status must be stopped')
            # suspension_history should contain the unsuspend record
            history = json.loads(row['suspension_history'])
            self.assertEqual(len(history), 1)
            self.assertIn('Unsuspended by admin', history[0]['reason'])

    @patch('arvm.execute_lxc', new_callable=MagicMock)
    def test_unsuspend_already_unsuspended(self, mock_exec):
        """Unsuspending a VPS that is not suspended is idempotent."""
        mock_exec.return_value = None
        self.login(as_admin=True)

        with arvm.get_db() as conn:
            conn.execute(
                "UPDATE vps SET suspended=0, suspended_reason=NULL, suspension_history='[]' WHERE id=1"
            )

        resp = self.client.post('/admin/vps/1/unsuspend',
                                content_type='application/json')
        data = resp.get_json()
        self.assertEqual(resp.status_code, 200, data)
        self.assertTrue(data['success'])

        # DB unchanged: suspended stays 0
        with arvm.get_db() as conn:
            row = conn.execute("SELECT suspended, suspended_reason FROM vps WHERE id=1").fetchone()
            self.assertEqual(row['suspended'], 0)
            self.assertIsNone(row['suspended_reason'])

    @patch('arvm.execute_lxc', new_callable=MagicMock)
    def test_unsuspend_restores_user_access(self, mock_exec):
        """After unsuspend, the VPS owner can access the detail page again."""
        mock_exec.return_value = None
        with arvm.get_db() as conn:
            conn.execute("UPDATE vps SET suspended=1, suspended_reason='test' WHERE id=1")

        # Log in as the VPS owner (user1)
        self.login(as_admin=False)

        # Before unsuspend, user is redirected to the suspended page
        resp = self.client.get('/vps/1')
        self.assertEqual(resp.status_code, 302)
        self.assertIn('suspended', resp.location.lower())

        # Log out and log in as admin to unsuspend
        self.client.get('/logout')
        self.login(as_admin=True)
        self.client.post('/admin/vps/1/unsuspend', content_type='application/json')
        self.client.get('/logout')

        # Now log in as owner again - should access VPS detail
        self.login(as_admin=False)
        resp = self.client.get('/vps/1', follow_redirects=True)
        self.assertEqual(resp.status_code, 200)
        self.assertNotIn('suspended', resp.location.lower() if resp.location else '')

    def test_unsuspend_requires_admin(self):
        """Regular user cannot unsuspend."""
        self.login(as_admin=False)

        resp = self.client.post('/admin/vps/1/unsuspend',
                                content_type='application/json')
        self.assertEqual(resp.status_code, 403)
        data = resp.get_json()
        self.assertFalse(data['success'])
        self.assertIn('Admin access required', data['error'])

    def test_unsuspend_not_found(self):
        """Returns 404 for nonexistent VPS."""
        self.login(as_admin=True)

        resp = self.client.post('/admin/vps/999/unsuspend',
                                content_type='application/json')
        self.assertEqual(resp.status_code, 404)
        data = resp.get_json()
        self.assertFalse(data['success'])
        self.assertIn('not found', data['error'].lower())

    @patch('arvm.execute_lxc', new_callable=MagicMock)
    def test_unsuspend_whitelisted_vps(self, mock_exec):
        """Whitelisted VPS can be unsuspended (unsuspend has no whitelist check)."""
        mock_exec.return_value = None
        with arvm.get_db() as conn:
            conn.execute("UPDATE vps SET suspended=1, whitelisted=1, suspended_reason='whitelisted' WHERE id=1")
        self.login(as_admin=True)

        resp = self.client.post('/admin/vps/1/unsuspend',
                                content_type='application/json')
        data = resp.get_json()
        self.assertEqual(resp.status_code, 200, data)
        self.assertTrue(data['success'])

        with arvm.get_db() as conn:
            row = conn.execute("SELECT suspended FROM vps WHERE id=1").fetchone()
            self.assertEqual(row['suspended'], 0)

    # ------------------------------------------------------------------ #
    #  FRONTEND ROUTES — user-facing (should NOT have suspend/unsuspend)
    # ------------------------------------------------------------------ #

    def test_vps_control_no_suspend(self):
        """User-facing /vps/<id>/control/<action> rejects 'suspend'."""
        self.login(as_admin=False)

        resp = self.client.post('/vps/1/control/suspend')
        self.assertEqual(resp.status_code, 400)
        data = resp.get_json()
        self.assertIn('Invalid action', data['error'])

    def test_vps_control_no_unsuspend(self):
        """User-facing /vps/<id>/control/<action> rejects 'unsuspend'."""
        self.login(as_admin=False)

        resp = self.client.post('/vps/1/control/unsuspend')
        self.assertEqual(resp.status_code, 400)
        data = resp.get_json()
        self.assertIn('Invalid action', data['error'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
