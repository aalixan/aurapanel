# ARVM Installation

For a fresh Ubuntu or Debian VPS, run the included installer as root:

```bash
chmod +x install.sh
sudo ./install.sh
```

The installer installs Python dependencies, imports the available keys from
initializes the database, and starts ARVM as a systemd service. The panel remains
locked until you enter a valid signed license key.

Manual installation is also supported on a Linux host with Python 3.8+:

```bash
cd /path/to/ARVM
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
```

Start the panel:

```bash
python3 arvm.py
```

Open `http://SERVER_IP:5000/` and paste the signed license key supplied by the ARVM owner.
Activation is verified cryptographically and stored locally for that installation.


For the node agent, use its existing installer separately:

```bash
sudo python3 node.py --install
```